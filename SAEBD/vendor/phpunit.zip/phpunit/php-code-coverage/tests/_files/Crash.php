<?php
class {CLASS}
